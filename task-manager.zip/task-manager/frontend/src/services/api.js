import axios from 'axios';

const API_URL = 'http://127.0.0.1:8000/api';  // Change this to your API URL.

const api = axios.create({
  baseURL: API_URL,
});

const registerUser = async (userData) => {
  const response = await api.post('/register/', userData);
  return response.data;
};

const loginUser = async (credentials) => {
  const response = await api.post('/token/', credentials);
  return response.data;
};

const createTask = async (taskData) => {
  const token = localStorage.getItem('access_token');
  const response = await api.post('/tasks/', taskData, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.data;
};

const getTasks = async () => {
  const token = localStorage.getItem('access_token');
  const response = await api.get('/tasks/', {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.data;
};

const updateTask = async (taskId, taskData) => {
  const token = localStorage.getItem('access_token');
  const response = await api.put(`/tasks/${taskId}/`, taskData, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.data;
};

const deleteTask = async (taskId) => {
  const token = localStorage.getItem('access_token');
  const response = await api.delete(`/tasks/${taskId}/`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.data;
};

export { registerUser, loginUser, createTask, getTasks, updateTask, deleteTask };
