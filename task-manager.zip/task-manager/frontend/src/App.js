import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import TaskList from './components/TaskList'; // The task list component
import TaskForm from './components/TaskForm'; // The form to add tasks
import TaskItems from './components/TaskItems'; // Task item display
import Header from './components/Header'; // Optional, if you want a header in the app
import "./App.css";
function App() {
  return (
    <Router>
      <div className="App">
        <Header />
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/tasks" element={<TaskList />} />
          <Route path="/tasks/create" element={<TaskForm />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
