import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TaskForm from './TaskForm';
import './TaskManager.css';

function TaskList() {
  const [tasks, setTasks] = useState([]);
  const [editingTask, setEditingTask] = useState(null);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await axios.get('http://127.0.0.1:8000/api/tasks/', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('access_token')}`,
        },
      });
      setTasks(response.data);
    } catch (error) {
      console.error('Error fetching tasks', error);
    }
  };

  const handleDelete = async (taskId) => {
    try {
      await axios.delete(`http://127.0.0.1:8000/api/tasks/${taskId}/`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('access_token')}`,
        },
      });
      setTasks(tasks.filter((task) => task.id !== taskId));
    } catch (error) {
      console.error('Error deleting task', error);
    }
  };

  return (
    <div className="container">
      <h2>Task Manager</h2>

      {/* Show Edit Form Only When Editing */}
      {editingTask ? (
        <>
          <TaskForm task={editingTask} setEditingTask={setEditingTask} refreshTasks={fetchTasks} />
          <button style={{marginTop:"10px"}} className="back-btn" onClick={() => setEditingTask(null)}>Back to Task List</button>
        </>
      ) : (
        <>
          <button className="create-btn" onClick={() => setEditingTask({})}>+ Create Task</button>
          <ul className="task-list">
            {tasks.map((task) => (
              <li key={task.id} className="task-item">
                <h3>{task.title}</h3>
                <p>{task.description}</p>
                <p><strong>Category:</strong> {task.category}</p>
                <p><strong>Priority:</strong> {task.priority}</p>
                <p><strong>Status:</strong> {task.status ? '✅ Completed' : '❌ Pending'}</p>
                <p><strong>Due Date:</strong> {task.due_date}</p>
                <div className="btn-group">
                  <button className="edit-btn" onClick={() => setEditingTask(task)}>Edit</button>
                  <button className="delete-btn" onClick={() => handleDelete(task.id)}>Delete</button>
                </div>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}

export default TaskList;
