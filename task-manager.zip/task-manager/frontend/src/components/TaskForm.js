import React, { useState, useEffect } from 'react';
import axios from 'axios';

function TaskForm({ task, setEditingTask, refreshTasks }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Work');
  const [priority, setPriority] = useState('Medium');
  const [status, setStatus] = useState(false);
  const [dueDate, setDueDate] = useState('');

  useEffect(() => {
    if (task) {
      setTitle(task.title || '');
      setDescription(task.description || '');
      setCategory(task.category || 'Work');
      setPriority(task.priority || 'Medium');
      setStatus(task.status || false);
      setDueDate(task.due_date || '');
    }
  }, [task]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const taskData = { title, description, category, priority, status, due_date: dueDate };

    try {
      if (task.id) {
        await axios.put(`http://127.0.0.1:8000/api/tasks/${task.id}/`, taskData, {
          headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` },
        });
        alert('Task updated successfully!');
      } else {
        await axios.post('http://127.0.0.1:8000/api/tasks/', taskData, {
          headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` },
        });
        alert('Task created successfully!');
      }

      setEditingTask(null);
      refreshTasks();
    } catch (error) {
      console.error('Error saving task', error);
    }
  };

  return (
    <div>
      <h2>{task.id ? 'Edit Task' : 'Create a New Task'}</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Task Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <textarea placeholder="Task Description" value={description} onChange={(e) => setDescription(e.target.value)} />

        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="Work">Work</option>
          <option value="Personal">Personal</option>
          <option value="Other">Other</option>
        </select>

        <select value={priority} onChange={(e) => setPriority(e.target.value)}>
          <option value="High">High</option>
          <option value="Medium">Medium</option>
          <option value="Low">Low</option>
        </select>

        <label>
          Status:
          <input type="checkbox" checked={status} onChange={() => setStatus(!status)} />
        </label>

        <input type="datetime-local" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />

        <button type="submit">{task.id ? 'Update Task' : 'Create Task'}</button>
        <button style={{marginTop:"5px"}} type="button" onClick={() => setEditingTask(null)}>Cancel</button>
      </form>
    </div>
  );
}

export default TaskForm;
