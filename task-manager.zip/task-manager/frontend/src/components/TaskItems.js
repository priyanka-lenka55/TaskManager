import React from 'react';
// import './TaskItems.css'; // Import the CSS for styling

function TaskItems({ tasks }) {
  return (
    <div className="task-items-container">
      {tasks.length === 0 ? (
        <p>No tasks available</p>
      ) : (
        tasks.map((task) => (
          <div key={task.id} className="task-item">
            <div className="task-row">
              <strong>Title:</strong>
              <span>{task.title}</span>
            </div>
            <div className="task-row">
              <strong>Description:</strong>
              <span>{task.description}</span>
            </div>
            <div className="task-row">
              <strong>Category:</strong>
              <span>{task.category}</span>
            </div>
            <div className="task-row">
              <strong>Priority:</strong>
              <span>{task.priority}</span>
            </div>
            <div className="task-row">
              <strong>Status:</strong>
              <span>{task.status ? 'Completed' : 'Pending'}</span>
            </div>
            <div className="task-row">
              <strong>Due Date:</strong>
              <span>{task.due_date ? new Date(task.due_date).toLocaleString() : 'N/A'}</span>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default TaskItems;
