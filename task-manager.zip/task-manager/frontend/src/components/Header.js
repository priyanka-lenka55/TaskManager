import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Header.css';

function Header() {
  const isLoggedIn = localStorage.getItem('access_token'); // Check if the user is logged in
  const navigate = useNavigate();

  const handleLogout = () => {
    // Clear the access token and log out the user
    localStorage.removeItem('access_token');
    navigate('/login'); // Redirect to login page after logout
  };

  return (
    <header className="header">
      <div className="logo">
        <Link to="/">Task Manager</Link>
      </div>
      <nav>
        <ul>
          {isLoggedIn ? (
            <>
              <li>
                <Link to="/tasks">
                <button >
                Home
                </button></Link>
              </li>
              <li>
                <button onClick={handleLogout} className="logout-btn">
                  Logout
                </button>
              </li>
            </>
          ) : (
            <>
              <li>
                <Link to="/login">Login</Link>
              </li>
              <li>
                <Link to="/register">Register</Link>
              </li>
            </>
          )}
        </ul>
      </nav>
    </header>
  );
}

export default Header;
