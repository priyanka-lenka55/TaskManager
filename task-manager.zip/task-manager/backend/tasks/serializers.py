from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Task

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email']



class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = ['id', 'title', 'description', 'category', 'priority', 'status', 'due_date', 'created_at']
        read_only_fields = ['id', 'created_at']

    def validate_status(self, value):
        if not isinstance(value, bool):
            raise serializers.ValidationError("Status must be a boolean (true/false).")
        return value
