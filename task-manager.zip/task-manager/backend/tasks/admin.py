from django.contrib import admin
from .models import Task

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'priority', 'status', 'due_date', 'created_at')
    list_filter = ('status', 'category', 'priority', 'due_date')
    search_fields = ('title', 'description')
    ordering = ('-created_at',)
